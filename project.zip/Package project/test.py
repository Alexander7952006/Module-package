from package import (load_table, save_table, get_rows_by_number, get_rows_by_index, get_column_types,
                     get_value, get_values, print_table, set_column_types, set_value, set_values)

table = load_table. load_table('csv', 'C:\\Users\\Alex\\Desktop\\Package project\\files\\test.csv')

#table = load_table. load_table('csv', 'C:\\Users\\Alex\\Desktop\\Package project\\files\\test.csv')

#print(table)

#print(get_rows_by_number. get_rows_by_number(table, 1, 3, copy_table = True))

#print(get_column_types. get_column_types(table))

#print(get_rows_by_index. get_rows_by_index(table,'Долгов', 'Алексеев', copy_table = True))

#print(get_value. get_value(table, 'Фамилия'))

#print(get_values. get_values(table, 'ЗП'))

#print(print_table. print_table(table))

#print(set_column_types. set_column_types(table, {3: float, 4: float, 5: float}))

#print(set_value. set_value(table, 'Третьяк', 1))

#print(set_values. set_values(table, ['Третьяк', 'Третьяк', 'Третьяк', 'Третьяк'], 1))

#print(table)

#save_table. save_table(table, 'C:\\Users\\Alex\\Desktop\\Package project\\files\\txt_table.txt', 'txt')

